package core.exceptions;

@SuppressWarnings("serial")
public class ErrorParseoCarta extends Exception {
	public ErrorParseoCarta(String msg) {
		super(msg);
	}
}